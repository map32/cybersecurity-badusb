# cybersecurity-badusb
raspberry pi pico based badusb that injects a keylogger in a windows system
